<div class="kg-video-container">
<div class="container-title">Most Viewed Videos</div>
<? foreach($videos as $video):?>
<? include('video_box.tpl.php')?>
<? endforeach;?>
</div>